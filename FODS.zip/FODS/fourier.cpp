#include <iostream>
#include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <math.h>
#include <iomanip>
#include <stdexcept>
using namespace std;

double getDeterminant(const  vector< vector<double>> vect) {
    if(vect.size() != vect[0].size()) {
        throw  runtime_error("Matrix is not quadratic");
    } 
    int dimension = vect.size();

    if(dimension == 0) {
        return 1;
    }

    if(dimension == 1) {
        return vect[0][0];
    }

    //Formula for 2x2-matrix
    if(dimension == 2) {
        return vect[0][0] * vect[1][1] - vect[0][1] * vect[1][0];
    }

    double result = 0;
    int sign = 1;
    for(int i = 0; i < dimension; i++) {

        //Submatrix
         vector< vector<double>> subVect(dimension - 1,  vector<double> (dimension - 1));
        for(int m = 1; m < dimension; m++) {
            int z = 0;
            for(int n = 0; n < dimension; n++) {
                if(n != i) {
                    subVect[m-1][z] = vect[m][n];
                    z++;
                }
            }
        }

        //recursive call
        result = result + sign * vect[0][i] * getDeterminant(subVect);
        sign = -sign;
    }

    return result;
}

 vector< vector<double>> getTranspose(const  vector< vector<double>> matrix1) {

    //Transpose-matrix: height = width(matrix), width = height(matrix)
     vector< vector<double>> solution(matrix1[0].size(),  vector<double> (matrix1.size()));

    //Filling solution-matrix
    for(size_t i = 0; i < matrix1.size(); i++) {
        for(size_t j = 0; j < matrix1[0].size(); j++) {
            solution[j][i] = matrix1[i][j];
        }
    }
    return solution;
}

 vector< vector<double>> getCofactor(const  vector< vector<double>> vect) {
    if(vect.size() != vect[0].size()) {
        throw  runtime_error("Matrix is not quadratic");
    } 

     vector< vector<double>> solution(vect.size(),  vector<double> (vect.size()));
     vector< vector<double>> subVect(vect.size() - 1,  vector<double> (vect.size() - 1));

    for( size_t i = 0; i < vect.size(); i++) {
        for( size_t j = 0; j < vect[0].size(); j++) {

            int p = 0;
            for(size_t x = 0; x < vect.size(); x++) {
                if(x == i) {
                    continue;
                }
                int q = 0;

                for(size_t y = 0; y < vect.size(); y++) {
                    if(y == j) {
                        continue;
                    }

                    subVect[p][q] = vect[x][y];
                    q++;
                }
                p++;
            }
            solution[i][j] = pow(-1, i + j) * getDeterminant(subVect);
        }
    }
    return solution;
}
 vector< vector<double>> getInverse(const  vector< vector<double>> vect) {
    if(getDeterminant(vect) == 0) {
        throw  runtime_error("Determinant is 0");
    } 

    double d = 1.0/getDeterminant(vect);
     vector< vector<double>> solution(vect.size(),  vector<double> (vect.size()));

    for(size_t i = 0; i < vect.size(); i++) {
        for(size_t j = 0; j < vect.size(); j++) {
            solution[i][j] = vect[i][j]; 
        }
    }

    solution = getTranspose(getCofactor(solution));

    for(size_t i = 0; i < vect.size(); i++) {
        for(size_t j = 0; j < vect.size(); j++) {
            solution[i][j] *= d;
        }
    }

    return solution;
}
vector<vector<double>> transpose(vector<vector<double>> m1)
{
    int M = m1.size();
    int N = m1[0].size();
    int i, j;
    vector<vector<double>> result(N, vector<double>(M,0));
    for (i = 0; i < N; i++)
        for (j = 0; j < M; j++)
            result[i][j] = m1[j][i];
        return result;
}
vector<vector<double>> mat_multiply(vector<vector<double>> m1, vector<vector<double>> m2)
{
    int a = m1.size();
    int b = m1[0].size();
    int m = m2.size();
    int n = m2[0].size();
    vector<vector<double>> result(a, vector<double>(n,0));
    if(b!=m)
    {
        cout<<"wrong multiplication format";
        return result;

    }
    for(int i=0;i<a;i++){
        for(int j=0;j<n;j++){
            for(int k=0;k<b;k++)
                result[i][j]+=m1[i][k]*m2[k][j];
        }
    }
        return result;
}

int main() {
        int num = 100;
        vector<double>x_cords;
        for(int i=0;i<num;i++)
        {
            x_cords.push_back(0.03*i);
        }
        vector<vector<double>> Y;
        for(int i=0;i<num;i++)
        {   
            vector<double>y_cords;
            y_cords.push_back(sin(x_cords[i]) + 3 + x_cords[i]);
            Y.push_back(y_cords);
        }
        vector<vector<double>> X;

        for(int i=0;i<num;i++)
        {
            vector<double>xrow = {sin(x_cords[i]), cos(x_cords[i]),sin(2*x_cords[i]), cos(2*x_cords[i]),1};
            X.push_back(xrow);
        }
        vector<vector<double>> final_sol = mat_multiply(getInverse( mat_multiply(getTranspose(X),X)),mat_multiply(getTranspose(X), Y));
        cout <<"the values for a,b,c :if the basis fn is a*sin(x)+b*cos(x)+c*sin(2x)+d*cos(2x) + e"<<endl;
        for(int i=0;i<final_sol.size();i++)
        {
            cout<<char('a' + i)<<" = " << final_sol[i][0]<<" ";
        }


        cout << endl << endl;
    return 0;
}
