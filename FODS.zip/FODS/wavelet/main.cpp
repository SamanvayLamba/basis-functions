#include <iostream>
#include <string>

#include "wavelet.h"

using namespace Vector;

int main(int argc, const char *argv[]) {
     std::cout << "default values of num_rows num_cols num_levels can be changed"<< std::endl;
  // Read arguments from command line
  if(argc < 3) {
    std::cout << "usage: " << std::string(argv[0]) << " num_rows num_cols num_levels   (default is 64 64 4)" << std::endl;
    return 1;
  }
 
  const size_t num_rows = static_cast<size_t>(std::stoi(argv[1]));
  const size_t num_cols = static_cast<size_t>(std::stoi(argv[2]));
  const size_t num_levels = static_cast<size_t>(std::stoi(argv[3]));

  Matrix<double> matrix(num_rows, num_cols);
  matrix.Rand();

  const double inv_sqrt2 = 1.0 / std::sqrt(2.0);
  const std::vector<double> Lo_D = {inv_sqrt2, inv_sqrt2};
  const std::vector<double> Hi_D = {-inv_sqrt2, inv_sqrt2};
  const std::vector<double> Lo_R = {inv_sqrt2, inv_sqrt2};
  const std::vector<double> Hi_R = {inv_sqrt2, -inv_sqrt2};

  const Wavelet<double> haar(Lo_D, Hi_D, Lo_R, Hi_R);
  const std::vector<double> vector = matrix.GetColumn(0);
  const Decomposition1D<double> dec1D = haar.Wavedec(vector, num_levels);
  const std::vector<double> vector_rec = haar.Waverec(dec1D, vector.size());
  const double norm1D = Norm(vector - vector_rec);


  std::cout << "Error 1D reconstruction: " << norm1D << std::endl;


  return 0;
}
